package com.salesianostriana.dam.proyectoapirecetas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoApiRecetasApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.salesianostriana.dam.proyectoapirecetas.Model;

public enum Dificultad {
    FACIL,
    MEDIA,
    DIFICIL
}

package com.salesianostriana.dam.proyectoapirecetas.Model;
import jakarta.persistence.*;
import lombok.*;

import java.util.Set;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
public class Categoria {
    @Id @GeneratedValue
    private Long id;
    private String name;
    private String descripcion;
    @OneToMany(mappedBy = "categoria", cascade = CascadeType.ALL)
    private Set<Receta>recetas;
}
package com.salesianostriana.dam.proyectoapirecetas.Repository;

import com.salesianostriana.dam.proyectoapirecetas.Model.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoriaRepository extends JpaRepository<Categoria,Long> {
}

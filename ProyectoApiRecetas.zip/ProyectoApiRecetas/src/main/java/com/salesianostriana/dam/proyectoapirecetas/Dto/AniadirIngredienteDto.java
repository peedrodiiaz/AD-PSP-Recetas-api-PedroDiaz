package com.salesianostriana.dam.proyectoapirecetas.Dto;

public record AniadirIngredienteDto(
        Long ingredienteId,
        String cantidad,
        String unidad
) {
}

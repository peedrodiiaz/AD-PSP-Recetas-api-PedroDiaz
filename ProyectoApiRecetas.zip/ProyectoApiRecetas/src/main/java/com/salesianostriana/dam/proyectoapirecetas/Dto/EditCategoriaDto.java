package com.salesianostriana.dam.proyectoapirecetas.Dto;

public record EditCategoriaDto(
        String nombre,
        String descripcion )
{


}
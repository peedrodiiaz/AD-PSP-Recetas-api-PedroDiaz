package com.salesianostriana.dam.proyectoapirecetas.Dto;

public record EditIngredienteDto(
        String nombre
) {
}

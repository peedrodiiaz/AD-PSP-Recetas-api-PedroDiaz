package com.salesianostriana.dam.proyectoapirecetas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoApiRecetasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoApiRecetasApplication.class, args);
	}

}
